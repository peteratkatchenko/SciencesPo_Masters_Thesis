CIE stands for China Industrial Enterprises
Monetary unit: thousand Yuan (CNY)

### Industry classification
Industrial industries hereby include:
6  coal mining
7  crude petroleum and natural gas
8  iron ores
9  miscellaneous metal ores
10 nonmetallic minerals
11 mining services
13 food processing
14 prepared food
15 beverages
16 tobacco products
17 textile products
18 apparel
19 leather products and footwear
20 lumber processing
21 furniture
22 papers and allied products
23 printing and recording media
24 recreational products
25 petroleum processing
26 chemical products
27 medical and pharmaceutical products
28 synthetic fiber
29 rubber and plastic products
30 nonmetal mineral products
31 smelting of ferrous metals
32 smelting of nonferrous metals
33 metal products
34 standard machinery
35 special machinery
36 motor vehicles
37 railroad equipment and aircraft
38 electrical machinery and equipment
39 computer communications equipment
40 apparatus
41 miscellaneous manufacturing
42 waste management
44 electric services
45 gas services
46 water supply

### Time range
The data span from 1998 to 2008. However, data quality varies across years. Some variables may be missing in certain years.


